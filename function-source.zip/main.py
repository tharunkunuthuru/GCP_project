from google.cloud import firestore
from datetime import datetime
import random

def generate_machine_data(request):
    db = firestore.Client()
    machines = ['machine1', 'machine2', 'machine3', 'machine4', 'machine5', 'machine6', 'machine7', 'machine8', 'machine9', 'machine10']
    
    for machine in machines:
        data = {
            'machine': machine,
            'timestamp': datetime.now(),
            'temperature': random.uniform(20, 30),
            'pressure': random.uniform(800, 1000),
            'humidity': random.uniform(40, 60),
        }
        db.collection('machine_data').add(data)

    return 'Data generated and stored successfully!'
